import { parseMobileAction } from '../src/mobile/actions.ts';

let passed = 0, failed = 0;
function check(ok: boolean, name: string) {
  if (ok) { passed++; console.log('PASS  ' + name); }
  else { failed++; console.log('FAIL  ' + name); }
}

const cases: Array<[string, string]> = [
  ['লাবণ্যকে কল করো', 'লাবণ্য'],
  ['Labanya ke call karo', 'Labanya'],
  ['Labonno call', 'Labonno'],
  ['লাবন্যকে ফোন করো', 'লাবন্য'],
  ['call Ma', 'Ma'],
  ['ফোন করো রাজেশ', 'রাজেশ'],
];
for (const [input, expect] of cases) {
  const parsed = parseMobileAction(input);
  check(parsed?.action === 'call_contact' && (parsed as any).recipient.replace(/কে$/, '').includes(expect.replace(/কে$/, '')),
    `parse '${input}' -> call_contact ${expect} (got ${JSON.stringify(parsed)})`);
}
check(parseMobileAction('call') === null, 'bare call is not an action');
check(parseMobileAction('কল করো +919876543210')?.action === 'call_number', 'explicit numbers still dial by number');

function compactKey(latin: string) {
  let s = latin.toLowerCase();
  s = s.replace(/kh/g, 'k').replace(/gh/g, 'g').replace(/ph/g, 'f').replace(/bh/g, 'b')
    .replace(/dh/g, 'd').replace(/th/g, 't').replace(/ch/g, 'c').replace(/sh/g, 's')
    .replace(/aa/g, 'a').replace(/ee/g, 'i').replace(/oo/g, 'u');
  s = s.replace(/nya/g, 'n').replace(/nno/g, 'n').replace(/nna/g, 'n').replace(/nyo/g, 'n')
    .replace(/nia/g, 'n').replace(/nn/g, 'n').replace(/ny/g, 'n');
  s = s.replace(/[vw]/g, 'b').replace(/y/g, 'i').replace(/o/g, 'a').replace(/e/g, 'a');
  s = s.replace(/(.)\1+/g, '$1').replace(/[^a-z0-9]+/g, '');
  return s;
}
const keys = ['labanya', 'labonya', 'labonno', 'lavanya', 'labanyo'].map(compactKey);
check(keys.every(k => k === keys[0]), `Labanya spelling variants share phonetic key (${keys[0]})`);
check(compactKey('labanya') !== compactKey('rajesh'), 'distinct names keep distinct keys');
console.log(`Passed: ${passed}  Failed: ${failed}`);
if (failed) process.exit(1);
