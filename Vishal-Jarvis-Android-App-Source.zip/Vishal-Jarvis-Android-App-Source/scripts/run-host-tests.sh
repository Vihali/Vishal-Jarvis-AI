#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if ! command -v javac >/dev/null 2>&1; then
  echo "JDK is required for HostVoiceTests."
  exit 2
fi
OUT="$(mktemp -d)"
javac -encoding UTF-8 -source 8 -target 8 -d "$OUT" \
  android/app/src/main/java/com/myraa/mobile/BengaliPhonetics.java \
  android/app/src/main/java/com/myraa/mobile/NameMatcher.java \
  android/app/src/main/java/com/myraa/mobile/SpeechEnhancer.java \
  android/host-tests/HostVoiceTests.java
java -cp "$OUT" HostVoiceTests
rm -rf "$OUT"
