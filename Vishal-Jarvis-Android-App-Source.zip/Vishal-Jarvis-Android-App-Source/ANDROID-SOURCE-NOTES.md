# Android source notes — Vishal Jarvis

The Android app keeps its original native package ID and bridge/prefs/event names for
compatibility, while its visible app name and assistant identity are Vishal Jarvis.
The mobile 3D character is now `src/mobile/RobotCharacter.ts`, a self-contained
procedural Three.js male android. It replaces the previously referenced external
Evelyn PMX model which was not included in this separated source ZIP.

The Android build no longer copies or requires third-party PMX model files. Its
mobile UI still uses the existing Gemini/Android chat, voice, settings, action and
history implementation.

Voice Intelligence 2.0 adds native AudioRecord capture with device
NoiseSuppressor/AEC/AGC when the hardware reports them, adaptive software speech
enhancement, Gemini Live reconnection, and phonetic Bengali/English contact
matching against the permitted Android Contacts database. Saved contact records
are never rewritten; user-approved spoken aliases stay in app preferences. Calls
still open the dialer only. See VOICE-INTELLIGENCE-2.0.md for the test report.
