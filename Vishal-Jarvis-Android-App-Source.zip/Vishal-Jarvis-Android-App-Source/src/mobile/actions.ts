export type MobileAction = { action: 'open_app'; app: string } | { action: 'search_youtube' | 'search_web'; query: string } | { action: 'whatsapp_message'; recipient: string; message: string } | { action: 'call_number'; phone: string } | { action: 'call_contact'; recipient: string } | { action: 'set_flashlight'; enabled: boolean } | { action: 'open_wifi_settings' };
export const MOBILE_TOOL = {
  name: 'mobile_action',
  description: 'Perform supported Android actions: open apps, search web/YouTube, prepare WhatsApp drafts, dial a supplied number, call a saved contact by name, switch the flashlight, or open Wi-Fi/Internet settings. Calls open the dialer only; the user taps Call. Contact names are resolved locally. Wi-Fi settings must be toggled by the user because Android does not allow ordinary apps to switch Wi-Fi directly. Never invent recipients, numbers or successful actions.',
  parameters: { type: 'OBJECT', properties: {
    action: { type: 'STRING', enum: ['open_app', 'search_youtube', 'search_web', 'whatsapp_message', 'call_number', 'call_contact', 'set_flashlight', 'open_wifi_settings'] },
    app: { type: 'STRING', description: 'App name, such as WhatsApp (WP), YouTube or Chrome. Only for open_app.' },
    query: { type: 'STRING', description: 'The exact search requested by the user. Required for search actions.' },
    recipient: { type: 'STRING', description: 'Saved contact name exactly as spoken in Bengali or English, including nicknames. Do not respell it. Or a full international phone number with country code. Contacts are resolved locally with phonetic matching.' },
    message: { type: 'STRING', description: 'Complete message the user requested. Ask for it if missing.' },
    phone: { type: 'STRING', description: 'Phone number explicitly provided by the user, including country code when possible. Only for call_number.' },
    enabled: { type: 'BOOLEAN', description: 'Whether the flashlight should be turned on or off. Only for set_flashlight.' },
  }, required: ['action'] },
};
/** Exact local typed commands; Live voice uses structured Gemini function calls. */
export function parseMobileAction(input: string): MobileAction | null {
  const digits = (value: string) => value.replace(/[০-৯]/g, d => String('০১২৩৪৫৬৭৮৯'.indexOf(d)));
  const text = digits(input.trim()).replace(/^(?:hey\s+)?(?:vishal\s+jarvis|vishal|roisal\s+jarvis|roisal|jarvis|myraa|myra|মায়া|মায়া)[,\s:]+/iu, '').replace(/^(?:please|can you|could you)\s+/i, '').trim();
  let call = /^(?:কল\s*(?:করো|কর|দাও)?|ফোন\s*করো|call(?:\s+to)?|dial)\s*[:,ঃ-]?\s*(?:এই\s+নম্বর(?:ে)?\s*)?([+0-9][0-9 ()-]{6,22})$/iu.exec(text) || /^([+0-9][0-9 ()-]{6,22})\s*(?:নম্বরে\s*)?(?:কল\s*করো|ফোন\s*করো)$/iu.exec(text);
  if (call) return { action: 'call_number', phone: call[1].trim() };
  if (/^(?:(?:ওয়াই|ওয়াই).?ফাই|wifi|wi-fi|ইন্টারনেট)(?:\s*(?:অন|চালু|on|enable))?\s*(?:করো|চালু করো|খোলো|open)?$/iu.test(text) || /^(?:(?:ওয়াই|ওয়াই).?ফাই|wifi|wi-fi)\s*(?:সেটিংস|settings)\s*(?:খোলো|open)?$/iu.test(text) || /^(?:turn\s+on\s+)?wi-?fi\s+(?:on|enable)$/i.test(text)) return { action: 'open_wifi_settings' };
  if (/^(?:ফ্ল্যাশ\s*লাইট|ফ্ল্যাশলাইট|টর্চ|torch|flashlight)\s*(?:অন|চালু|on|ওপেন|খোলো|open)(?:\s*করো)?$/iu.test(text) || /^(?:অন|চালু|ওপেন|open)\s*(?:করো\s*)?(?:ফ্ল্যাশ\s*লাইট|ফ্ল্যাশলাইট|টর্চ|torch|flashlight)$/iu.test(text) || /^turn\s+on\s+(?:the\s+)?flashlight$/i.test(text)) return { action: 'set_flashlight', enabled: true };
  if (/^(?:ফ্ল্যাশ\s*লাইট|ফ্ল্যাশলাইট|টর্চ|torch|flashlight)\s*(?:অফ|বন্ধ|off)(?:\s*করো)?$/iu.test(text) || /^(?:বন্ধ|অফ)\s*(?:করো\s*)?(?:ফ্ল্যাশ\s*লাইট|ফ্ল্যাশলাইট|টর্চ|torch|flashlight)$/iu.test(text) || /^turn\s+off\s+(?:the\s+)?flashlight$/i.test(text)) return { action: 'set_flashlight', enabled: false };
  let contactCall = /^(?:এই নাম্বারে থাকা )?(.+?)\s*(?:কে|কে|ke|ko)?\s*(?:কল|ফোন|call|phone|dial)\s*(?:করো|কর|দাও|karo|koro)?$/iu.exec(text)
    || /^(?:কল|ফোন|call|phone|dial)(?:\s+(?:করো|কর|দাও|karo|koro|to))?\s+(.+?)(?:\s*(?:কে|কে|ke))?$/iu.exec(text)
    || /^(.+?)\s+(?:ke|ko|কে|কে)\s+(?:call|phone|fon|কল|ফোন)\s*(?:karo|koro|করো|কর)?$/iu.exec(text)
    || /^(.+?)\s+(?:call|phone|কল|ফোন)$/iu.exec(text)
    || /^call\s+(.+)$/i.exec(text);
  if (contactCall && contactCall[1].trim() && !/^[+0-9][0-9 ()+-]*$/.test(contactCall[1].trim())) {
    const recipient = contactCall[1].trim().replace(/\s+নামে$/, '').replace(/(?:কে|কে)$/u, '');
    if (recipient && !/^(?:call|phone|কল|ফোন)$/i.test(recipient)) return { action: 'call_contact', recipient };
  }
  call = /^(?:কল\s*(?:করো|কর|দাও)|ফোন\s*করো|call|dial)$/iu.exec(text);
  if (call) return null;
  let match = /^(?:open\s+)?(?:youtube|you tube)(?:\s+and)?\s+search(?:\s+for)?\s+(.+)$/i.exec(text) || /^search(?:\s+for)?\s+(.+?)\s+on\s+youtube$/i.exec(text);
  if (match) return { action: 'search_youtube', query: match[1].trim() };
  match = /^(?:open\s+)?(?:chrome|google chrome|browser)(?:\s+and)?\s+search(?:\s+for)?\s+(.+)$/i.exec(text) || /^search(?:\s+for)?\s+(.+?)\s+(?:on|in)\s+(?:chrome|google|browser)$/i.exec(text);
  if (match) return { action: 'search_web', query: match[1].trim() };
  match = /^(?:message|msg|text)\s+(.+?)\s+(?:on|using)\s+(?:whatsapp|wp|wa)\s*:\s*(.+)$/is.exec(text) || /^(?:whatsapp|wp|wa)\s+(?:message|msg)(?:\s+to)?\s+(.+?)\s*:\s*(.+)$/is.exec(text);
  if (match) return { action: 'whatsapp_message', recipient: match[1].trim(), message: match[2].trim() };
  const openText = text.replace(/[.!?।]+$/u, '');
  match = /^(?:open|launch)\s+([\p{L}\p{N}][\p{L}\p{N} ._-]{0,79})$/iu.exec(openText) || /^(whatsapp|wp|wa|youtube|chrome)\s+(?:kholo|khol do|open karo)$/i.exec(openText);
  if (match && !/\band\b/i.test(match[1])) return { action: 'open_app', app: match[1].trim() };
  return null;
}
