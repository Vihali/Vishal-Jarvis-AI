export type MobileAction = { action: 'open_app'; app: string } | { action: 'search_youtube' | 'search_web'; query: string } | { action: 'whatsapp_message'; recipient: string; message: string } | { action: 'set_flashlight'; enabled: boolean } | { action: 'open_wifi_settings' | 'open_bluetooth_settings' | 'device_status' } | { action: 'set_volume'; stream: 'media' | 'system'; level: 'up' | 'down' | 'full' | 'mute' } | { action: 'set_alarm'; hour: number; minute: number };
export const MOBILE_TOOL = {
  name: 'mobile_action',
  description: 'Perform supported Android actions: open apps, search web/YouTube, prepare WhatsApp drafts, switch the flashlight, read battery/storage/internet status, change media or system volume, open an alarm app, and open Wi-Fi or Bluetooth settings. Wi-Fi and Bluetooth switches require user interaction. Alarms require confirmation in the alarm app. Never invent recipients, numbers or successful actions.',
  parameters: { type: 'OBJECT', properties: {
    action: { type: 'STRING', enum: ['open_app', 'search_youtube', 'search_web', 'whatsapp_message', 'set_flashlight', 'open_wifi_settings', 'open_bluetooth_settings', 'device_status', 'set_volume', 'set_alarm'] },
    app: { type: 'STRING', description: 'App name, such as WhatsApp (WP), YouTube or Chrome. Only for open_app.' },
    query: { type: 'STRING', description: 'The exact search requested by the user. Required for search actions.' },
    recipient: { type: 'STRING', description: 'Saved contact name as spoken, or a full international phone number with country code. Contacts are resolved locally.' },
    message: { type: 'STRING', description: 'Complete message the user requested. Ask for it if missing.' },
    stream: { type: 'STRING', enum: ['media', 'system'] },
    level: { type: 'STRING', enum: ['up', 'down', 'full', 'mute'] },
    hour: { type: 'INTEGER', description: 'Alarm hour in 24-hour format (0–23).' },
    minute: { type: 'INTEGER', description: 'Alarm minute (0–59).' },
    enabled: { type: 'BOOLEAN', description: 'Whether the flashlight should be turned on or off. Only for set_flashlight.' },
  }, required: ['action'] },
};
/** Exact local typed commands; Live voice uses structured Gemini function calls. */
export function parseMobileAction(input: string): MobileAction | null {
  const digits = (value: string) => value.replace(/[০-৯]/g, d => String('০১২৩৪৫৬৭৮৯'.indexOf(d)));
  const text = digits(input.trim()).replace(/^(?:hey\s+)?(?:vishal\s+jarvis|vishal|roisal\s+jarvis|roisal|jarvis|myraa|myra|মায়া|মায়া)[,\s:]+/iu, '').replace(/^(?:please|can you|could you)\s+/i, '').trim();
  if (/^(?:(?:ওয়াই|ওয়াই).?ফাই|wifi|wi-fi|ইন্টারনেট)(?:\s*(?:অন|চালু|on|enable))?\s*(?:করো|চালু করো|খোলো|open)?$/iu.test(text) || /^(?:(?:ওয়াই|ওয়াই).?ফাই|wifi|wi-fi)\s*(?:সেটিংস|settings)\s*(?:খোলো|open)?$/iu.test(text) || /^(?:turn\s+on\s+)?wi-?fi\s+(?:on|enable)$/i.test(text)) return { action: 'open_wifi_settings' };
  if (/^(?:ফ্ল্যাশ\s*লাইট|ফ্ল্যাশলাইট|টর্চ|torch|flashlight)\s*(?:অন|চালু|on|ওপেন|খোলো|open)(?:\s*করো)?$/iu.test(text) || /^(?:অন|চালু|ওপেন|open)\s*(?:করো\s*)?(?:ফ্ল্যাশ\s*লাইট|ফ্ল্যাশলাইট|টর্চ|torch|flashlight)$/iu.test(text) || /^turn\s+on\s+(?:the\s+)?flashlight$/i.test(text)) return { action: 'set_flashlight', enabled: true };
  if (/^(?:ফ্ল্যাশ\s*লাইট|ফ্ল্যাশলাইট|টর্চ|torch|flashlight)\s*(?:অফ|বন্ধ|off)(?:\s*করো)?$/iu.test(text) || /^(?:বন্ধ|অফ)\s*(?:করো\s*)?(?:ফ্ল্যাশ\s*লাইট|ফ্ল্যাশলাইট|টর্চ|torch|flashlight)$/iu.test(text) || /^turn\s+off\s+(?:the\s+)?flashlight$/i.test(text)) return { action: 'set_flashlight', enabled: false };
  if (/^(?:battery|storage|internet status|device status|ব্যাটারি|স্টোরেজ)(?:\s+(?:status|level|কত|স্ট্যাটাস))?[?।.!]*$/iu.test(text)) return { action: 'device_status' };
  if (/^(?:bluetooth|ব্লুটুথ)\s*(?:settings|সেটিংস|খোলো)?$/iu.test(text)) return { action: 'open_bluetooth_settings' };
  let match = /^(?:open\s+)?(?:youtube|you tube)(?:\s+and)?\s+search(?:\s+for)?\s+(.+)$/i.exec(text) || /^search(?:\s+for)?\s+(.+?)\s+on\s+youtube$/i.exec(text);
  if (match) return { action: 'search_youtube', query: match[1].trim() };
  match = /^(?:open\s+)?(?:chrome|google chrome|browser)(?:\s+and)?\s+search(?:\s+for)?\s+(.+)$/i.exec(text) || /^search(?:\s+for)?\s+(.+?)\s+(?:on|in)\s+(?:chrome|google|browser)$/i.exec(text);
  if (match) return { action: 'search_web', query: match[1].trim() };
  match = /^(?:message|msg|text)\s+(.+?)\s+(?:on|using)\s+(?:whatsapp|wp|wa)\s*:\s*(.+)$/is.exec(text) || /^(?:whatsapp|wp|wa)\s+(?:message|msg)(?:\s+to)?\s+(.+?)\s*:\s*(.+)$/is.exec(text);
  if (match) return { action: 'whatsapp_message', recipient: match[1].trim(), message: match[2].trim() };
  const openText = text.replace(/[.!?।]+$/u, '');
  match = /^(?:open|launch)\s+([\p{L}\p{N}][\p{L}\p{N} ._-]{0,79})$/iu.exec(openText) || /^(whatsapp|wp|wa|youtube|chrome)\s+(?:kholo|khol do|open karo)$/i.exec(openText);
  if (match && !/\band\b/i.test(match[1])) return { action: 'open_app', app: match[1].trim() };
  return null;
}
