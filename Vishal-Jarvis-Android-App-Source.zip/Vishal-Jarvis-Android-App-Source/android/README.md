# Vishal Jarvis Android

Standalone Android application. Native Java handles encrypted Gemini credentials,
HTTPS requests, local conversation history, Android TTS and lifecycle. The bundled
HTML/TypeScript app contains the chat/voice interface and a self-contained Three.js
procedural 3D male android companion. No external PMX/VRM model or character texture
folder is required for the robot to render.

## Requirements

Android 8.0 / API 26 or later, Android System WebView 100 or later, and OpenGL ES 3.
Target API 35. Chat and Gemini Live voice require the user's own API key, network
access and access to the selected Google model. The key is encrypted with Android
Keystore and is not bundled.

## Build on Windows

Install Node.js, JDK 21, Android SDK platform 35 and build-tools 35.0.0. From the
project root:

```powershell
npm install
pwsh -NoProfile -File scripts/build-android.ps1 -SdkRoot 'C:\path\to\android-sdk' -JavaRoot 'C:\path\to\jdk-21'
```

The script runs Vite, javac, D8, AAPT2, zipalign and apksigner. Output:

`artifacts/android/Vishal-Jarvis-1.1.0-private.apk`

Install with `adb install -r <apk-path>` or copy the APK to the phone and install it.
The development package ID remains `com.myraa.mobile` for compatibility with the
previous app identity; the launcher name is Vishal Jarvis.

## Character

`src/mobile/RobotCharacter.ts` procedurally builds the robotic male companion using
Three.js primitives and metallic/emissive materials. It has animated idle motion,
head tracking, voice-reactive eye/core/mouth effects, and wave/dance/sit/stand poses.
It is bundled directly into the mobile web assets and does not load remote character
files.

## Existing app behavior

The Android source retains Gemini chat/Live voice, TTS, app launch, Chrome/web and
YouTube search, phonetic local contact lookup, WhatsApp draft creation, settings and history.
WhatsApp messages remain drafts and are not sent without the user's tap. This app
does not provide unrestricted Android UI control, screen capture or filesystem access.

## Validation

A source update is not proof of a successful APK or physical-device run. After
building, test startup, 3D rendering, permissions, text chat, Live voice, app actions,
background lifecycle and battery/thermal behavior on a real target device.
