import com.myraa.mobile.BengaliPhonetics;
import com.myraa.mobile.NameMatcher;
import com.myraa.mobile.SpeechEnhancer;
import java.util.*;

/** Host-side tests for Voice Intelligence 2.0. No Android runtime required. */
public final class HostVoiceTests {
  private static int passed;
  private static int failed;
  private static final StringBuilder log = new StringBuilder();

  public static void main(String[] args) {
    contactExtraction();
    labanyaMatching();
    similarNamesStayAmbiguous();
    aliasesAndNicknames();
    englishAndPartial();
    speechEnhancer();
    System.out.print(log);
    System.out.println("Passed: " + passed + "  Failed: " + failed);
    if (failed > 0) System.exit(1);
  }

  private static void check(boolean ok, String name) {
    if (ok) { passed++; log.append("PASS  ").append(name).append('\n'); }
    else { failed++; log.append("FAIL  ").append(name).append('\n'); }
  }

  private static void contactExtraction() {
    check(NameMatcher.extractSpokenName("লাবণ্যকে কল করো").contains("লাবণ্য") || NameMatcher.extractSpokenName("লাবণ্যকে কল করো").equals("লাবণ্য"),
      "extract Bengali 'লাবণ্যকে কল করো'");
    check("Labanya".equalsIgnoreCase(NameMatcher.extractSpokenName("Labanya ke call karo")), "extract 'Labanya ke call karo'");
    check("Labonno".equalsIgnoreCase(NameMatcher.extractSpokenName("Labonno call")), "extract 'Labonno call'");
    check(NameMatcher.extractSpokenName("লাবন্যকে ফোন করো").startsWith("লাবন্য"), "extract 'লাবন্যকে ফোন করো'");
    check("Ma".equalsIgnoreCase(NameMatcher.extractSpokenName("call Ma")) || "Ma".equals(NameMatcher.extractSpokenName("Call Ma")), "extract English call command");
  }

  private static List<NameMatcher.Contact> book() {
    List<NameMatcher.Contact> contacts = new ArrayList<>();
    contacts.add(new NameMatcher.Contact("লাবণ্য", "919800000001"));
    contacts.add(new NameMatcher.Contact("Rajesh Kumar", "919800000002"));
    contacts.add(new NameMatcher.Contact("রাজ", "919800000003"));
    contacts.add(new NameMatcher.Contact("রাজা", "919800000004"));
    contacts.add(new NameMatcher.Contact("রাজেশ", "919800000005"));
    contacts.add(new NameMatcher.Contact("John Smith", "919800000006"));
    contacts.add(new NameMatcher.Contact("Jon", "919800000007"));
    contacts.add(new NameMatcher.Contact("Sam A", "919800000008"));
    contacts.add(new NameMatcher.Contact("Sam B", "919800000009"));
    contacts.add(new NameMatcher.Contact("Father", "919800000010", Arrays.asList("Bapi", "বাবা")));
    contacts.add(new NameMatcher.Contact("Catherine", "919800000011"));
    return contacts;
  }

  private static void labanyaMatching() {
    List<NameMatcher.Contact> contacts = book();
    String[] queries = {
      "লাবণ্য", "লাবণ্যকে কল করো", "Labanya", "Labanya ke call karo", "Labonno call", "লাবন্যকে ফোন করো", "Labonya", "Lavanya"
    };
    for (String query : queries) {
      NameMatcher.Decision d = NameMatcher.match(query, contacts);
      boolean hit = d.best != null && "লাবণ্য".equals(d.best.name) && !"choose".equals(d.verdict) && !"none".equals(d.verdict);
      check(hit, "match '" + query + "' -> লাবণ্য (" + d.verdict + " " + (d.best == null ? "-" : d.best.score) + " " + (d.best == null ? "" : d.best.reason) + ")");
    }
    NameMatcher.Decision missing = NameMatcher.match("xyzabc", contacts);
    check("none".equals(missing.verdict), "unknown name is not called");
  }

  private static void similarNamesStayAmbiguous() {
    List<NameMatcher.Contact> contacts = book();
    NameMatcher.Decision sam = NameMatcher.match("Sam", contacts);
    check("choose".equals(sam.verdict), "Sam A vs Sam B requires a choice, never auto-call");
    NameMatcher.Decision raj = NameMatcher.match("রাজ", contacts);
    boolean safe = "choose".equals(raj.verdict) || "confirm".equals(raj.verdict) || (raj.best != null && "রাজ".equals(raj.best.name) && ("exact".equals(raj.verdict) || "confident".equals(raj.verdict)));
    check(safe, "রাজ does not silently call রাজা or রাজেশ");
    if ("exact".equals(raj.verdict) || "confident".equals(raj.verdict)) {
      check("রাজ".equals(raj.best.name), "exact রাজ selects রাজ");
    }
  }

  private static void aliasesAndNicknames() {
    List<NameMatcher.Contact> contacts = book();
    NameMatcher.Decision nick = NameMatcher.match("Bapi", contacts);
    check(nick.best != null && "Father".equals(nick.best.name) && !"none".equals(nick.verdict) && !"choose".equals(nick.verdict),
      "Android nickname Bapi matches Father");
    Map<String, String> aliases = new HashMap<>();
    aliases.put("labonno", "লাবণ্য");
    NameMatcher.Decision learned = NameMatcher.match("Labonno", contacts, aliases);
    check(learned.best != null && "লাবণ্য".equals(learned.best.name) && learned.best.score >= 0.9,
      "user-approved alias Labonno -> লাবণ্য");
  }

  private static void englishAndPartial() {
    List<NameMatcher.Contact> contacts = book();
    NameMatcher.Decision cat = NameMatcher.match("Katherine", contacts);
    check(cat.best != null && "Catherine".equals(cat.best.name) && !"none".equals(cat.verdict),
      "Katherine matches Catherine");
    NameMatcher.Decision partial = NameMatcher.match("Labany", contacts);
    check(partial.best != null && "লাবণ্য".equals(partial.best.name), "partial Labany still ranks লাবণ্য first");
    check(!"choose".equals(partial.verdict) || partial.ranked.size() > 1, "partial match does not invent extra people");
  }

  private static void speechEnhancer() {
    SpeechEnhancer enhancer = new SpeechEnhancer();
    byte[] noise = tone(0, 0.04f, 0.035f, 40);
    for (int i = 0; i < 40; i++) {
      byte[] frame = Arrays.copyOfRange(noise, i * SpeechEnhancer.FRAME * 2, (i + 1) * SpeechEnhancer.FRAME * 2);
      enhancer.calibrateNoise(frame, 0, frame.length);
    }
    check(enhancer.isCalibrated(), "microphone calibration completes in ~400 ms of ambient audio");
    check(enhancer.noiseFloorDb() < -10, "noise floor estimated from ambient audio (" + enhancer.noiseFloorDb() + " dB)");

    SpeechEnhancer noisy = new SpeechEnhancer();
    calibrate(noisy, 0.04f);
    byte[] noisySpeech = tone(1000, 0.22f, 0.12f, 30);
    double inSnr = snr(noisySpeech, 1000);
    for (int i = 0; i < 30; i++) {
      byte[] frame = Arrays.copyOfRange(noisySpeech, i * SpeechEnhancer.FRAME * 2, (i + 1) * SpeechEnhancer.FRAME * 2);
      noisy.process(frame, 0, frame.length);
      System.arraycopy(frame, 0, noisySpeech, i * SpeechEnhancer.FRAME * 2, frame.length);
    }
    double outSnr = snr(noisySpeech, 1000);
    check(outSnr > inSnr, "Wiener suppression improves SNR of 1 kHz speech in noise (" + round(inSnr) + " -> " + round(outSnr) + " dB)");

    SpeechEnhancer vad = new SpeechEnhancer();
    calibrate(vad, 0.01f);
    boolean silence = false, speech = false;
    byte[] quiet = tone(0, 0, 0.004f, 10);
    for (int i = 0; i < 10; i++) {
      byte[] frame = Arrays.copyOfRange(quiet, i * SpeechEnhancer.FRAME * 2, (i + 1) * SpeechEnhancer.FRAME * 2);
      if (!vad.process(frame, 0, frame.length)) silence = true;
    }
    byte[] voice = tone(700, 0.2f, 0.01f, 20);
    for (int i = 0; i < 20; i++) {
      byte[] frame = Arrays.copyOfRange(voice, i * SpeechEnhancer.FRAME * 2, (i + 1) * SpeechEnhancer.FRAME * 2);
      if (vad.process(frame, 0, frame.length)) speech = true;
    }
    check(silence, "VAD stays off for quiet ambient noise");
    check(speech, "VAD detects a voiced 700 Hz tone after hangover rules");

    SpeechEnhancer agc = new SpeechEnhancer();
    calibrate(agc, 0.008f);
    byte[] quietVoice = tone(900, 0.03f, 0.004f, 25);
    double before = rms(quietVoice);
    for (int i = 0; i < 25; i++) {
      byte[] frame = Arrays.copyOfRange(quietVoice, i * SpeechEnhancer.FRAME * 2, (i + 1) * SpeechEnhancer.FRAME * 2);
      agc.process(frame, 0, frame.length);
      System.arraycopy(frame, 0, quietVoice, i * SpeechEnhancer.FRAME * 2, frame.length);
    }
    double after = rms(Arrays.copyOfRange(quietVoice, quietVoice.length / 2, quietVoice.length));
    check(after > before * 1.3, "AGC raises quiet speech (" + round(before) + " -> " + round(after) + ")");
    check(!agc.clipping(), "AGC does not clip the raised speech");

    float[] re = new float[SpeechEnhancer.FFT];
    float[] im = new float[SpeechEnhancer.FFT];
    re[0] = 1;
    SpeechEnhancer.fft(re, im, false);
    SpeechEnhancer.fft(re, im, true);
    check(Math.abs(re[0] - 1) < 1e-3 && Math.abs(re[1]) < 1e-3, "round-trip FFT preserves an impulse");
  }

  private static void calibrate(SpeechEnhancer enhancer, float noiseAmp) {
    byte[] noise = tone(0, 0, noiseAmp, 24);
    for (int i = 0; i < 24; i++) {
      byte[] frame = Arrays.copyOfRange(noise, i * SpeechEnhancer.FRAME * 2, (i + 1) * SpeechEnhancer.FRAME * 2);
      enhancer.calibrateNoise(frame, 0, frame.length);
    }
  }

  private static byte[] tone(double hz, float amp, float noise, int frames) {
    int n = frames * SpeechEnhancer.FRAME;
    byte[] pcm = new byte[n * 2];
    Random random = new Random(7);
    for (int i = 0; i < n; i++) {
      double t = i / (double) SpeechEnhancer.SAMPLE_RATE;
      double s = amp * Math.sin(2 * Math.PI * hz * t) + noise * (random.nextDouble() * 2 - 1);
      if (s > 0.97) s = 0.97;
      if (s < -0.97) s = -0.97;
      int v = (int) Math.round(s * 32767);
      pcm[i * 2] = (byte) (v & 0xff);
      pcm[i * 2 + 1] = (byte) ((v >> 8) & 0xff);
    }
    return pcm;
  }

  private static double rms(byte[] pcm) {
    double e = 0; int n = pcm.length / 2;
    for (int i = 0; i < n; i++) {
      int v = (short) ((pcm[i * 2 + 1] << 8) | (pcm[i * 2] & 0xff));
      double x = v / 32768.0;
      e += x * x;
    }
    return Math.sqrt(e / Math.max(1, n));
  }

  private static double snr(byte[] pcm, double hz) {
    int n = pcm.length / 2;
    double s = 0, noise = 0;
    for (int i = 0; i < n; i++) {
      int v = (short) ((pcm[i * 2 + 1] << 8) | (pcm[i * 2] & 0xff));
      double x = v / 32768.0;
      double t = i / (double) SpeechEnhancer.SAMPLE_RATE;
      double ref = Math.sin(2 * Math.PI * hz * t);
      s += x * ref;
      noise += x * x;
    }
    s = (2 * s / n); // ~amplitude of the tone
    double signal = s * s / 2;
    double total = noise / n;
    double nPow = Math.max(1e-9, total - signal);
    return 10 * Math.log10(Math.max(1e-9, signal) / nPow);
  }

  private static String round(double value) { return String.format(Locale.US, "%.2f", value); }
}
