/** Static safeguards supplement on-device instrumentation of the durable job. */
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = (path: string) => readFileSync(path, 'utf8');
const activity = read('android/app/src/main/java/com/myraa/mobile/MainActivity.java');
const actions = read('android/app/src/main/java/com/myraa/mobile/MobileActions.java');
const manifest = read('android/app/src/main/AndroidManifest.xml');
const coordinator = read('android/app/src/main/java/com/myraa/mobile/AiTaskCoordinator.java');
const ui = read('src/mobile/main.ts');
for (const source of [activity, actions]) {
  for (const match of source.matchAll(/requestPermissions\s*\(([^;]+);/gs)) {
    assert.doesNotMatch(match[1], /READ_PHONE_STATE|READ_PHONE_NUMBERS/, 'SIM access must not be requested automatically');
  }
}
assert.match(actions, /simInfo[\s\S]*?No SIM access request was made/);
assert.doesNotMatch(manifest, /android\.permission\.READ_PHONE_NUMBERS/, 'unused SIM-number permission is not declared');
for (const permission of ['CALL_PHONE', 'SEND_SMS', 'READ_CONTACTS', 'CAMERA', 'RECORD_AUDIO'])
  assert.ok(manifest.includes(`android.permission.${permission}`), `keep unrelated ${permission} permission`);
assert.match(manifest, /AiTaskJobService[\s\S]*?BIND_JOB_SERVICE/);
assert.match(manifest, /AiTaskForegroundService[\s\S]*?dataSync/);
assert.match(coordinator, /setRequiredNetworkType\(JobInfo.NETWORK_TYPE_ANY\)/);
assert.match(coordinator, /setPersisted\(true\)/);
assert.match(coordinator, /setBackoffCriteria/);
const pagehide = ui.match(/window\.addEventListener\('pagehide'[^\n]*/)?.[0] || '';
assert.doesNotMatch(pagehide, /cancel\(/, 'closing the Activity must not cancel saved tasks');
for (const feature of ['search-toggle', 'share-history', 'save-history-file', 'text-size', 'theme', 'avatar']) assert.ok(ui.includes(feature));
console.log('Background scheduling, SIM prompt, existing UI and export contracts passed.');
